---
name: swap-stations
description: 查询蔚来/乐道共享换电站信息。支持按城市查询、计算最近换电站、引导查看完整换电地图。
version: 0.1.0
---

# 换电站查询

## 数据来源

蔚来换电站数据通过以下方式获取：

1. **乐道加电地图**（官方实时地图）：`https://www.onvo.cn/map`
2. **社区开源爬虫**：[alantoa/china-ev-spider](https://github.com/alantoa/china-ev-spider) — 可获取换电站位置数据（经纬度、名称、地址等）
3. **乐道加电服务页**：`https://www.onvo.cn/power`

## 调用方式

通过报价系统的 `/swap-stations` 接口查询（完整路径：`http://localhost:5000/api/swap-stations`）。

**请求参数：**
- `city`（必填）：城市名称，如 "福州"
- `user_lat`（可选）：用户纬度，用于计算最近换电站
- `user_lng`（可选）：用户经度，用于计算最近换电站

**返回数据：**
```json
{
  "city": "福州",
  "total_stations": 28,
  "nearest": {
    "name": "XX换电站",
    "address": "XX区XX路XX号",
    "distance_km": 3.2,
    "supports_onvo": true,
    "lat": 26.0745,
    "lng": 119.2965
  },
  "stations": [
    { "name": "...", "address": "...", "distance_km": 3.2, "supports_onvo": true },
    { "name": "...", "address": "...", "distance_km": 5.8, "supports_onvo": true }
  ]
}
```

## 回复话术

**基础回复模板：**

> [城市名]目前有 XX 座换电站，乐道都可以使用。
>
> 离您最近的是 [换电站名称]，在 [地址]，大约 X 公里。
>
> 想看所有换电站的详细位置和地图，可以点这里：[乐道加电地图](https://www.onvo.cn/map)

**引导留资话术：**

> 您大概在哪个位置？告诉我一下，我帮您查最近的换电站。或者留个电话，我把详细位置发给您。

## 全国数据概览（截至2026年初）

| 指标 | 数量 |
|------|------|
| 蔚来换电站总数 | ~3,700+ 座 |
| 支持乐道换电的换电站 | ~2,300+ 座 |
| 高速公路换电站 | ~1,000+ 座 |

## 注意事项

1. 乐道共享蔚来换电网络，但不是所有蔚来换电站都支持乐道（部分第五代站支持）
2. 换电站数据是动态更新的，回复时必须注明"数据以实际为准"
3. 引导用户到蔚来加电地图查看完整地图，而不是自己绘制地图
