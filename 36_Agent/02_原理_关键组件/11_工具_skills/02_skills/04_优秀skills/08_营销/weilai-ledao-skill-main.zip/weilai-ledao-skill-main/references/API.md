# 乐道报价系统 API 接口文档

> 这是 AI Skill 期望的后端 API 接口规范。实际开发时以此为准。

## 基础信息

- **Base URL**: `http://localhost:5000/api/`
- **协议**: REST API
- **返回格式**: JSON
- **方法**: 所有接口均为 GET 请求（查询类接口）

## 接口列表

### 1. 车型信息 `GET /models`

**参数**：`model`（可选，L60/L90）

**返回**：
```json
{
  "models": [
    {
      "name": "L60",
      "versions": ["标准版", "长续航版", "顶配版"],
      "battery": "75kWh / 100kWh",
      "range": "约 500km / 约 600km",
      "exterior_colors": ["颜色1", "颜色2"],
      "interior_colors": ["颜色1", "颜色2"],
      "options": [
        {"name": "NOMI", "price": 4900},
        {"name": "舒享套装", "price": 3500}
      ]
    }
  ]
}
```

### 2. 价格查询 `GET /prices`

**参数**：`model`、`version`、`purchase_type`（baas/buyout）

**返回**：
```json
{
  "model": "L60",
  "prices": {
    "baas": { "standard": 206900, "long_range": 236900, "top": 0 },
    "buyout": { "standard": 0, "long_range": 0, "top": 0 },
    "battery_rent": 599
  }
}
```

### 3. BaaS vs 买断对比 `GET /baas-compare`

**参数**：`model`、`months`（36/60）

**返回**：
```json
{
  "model": "L60",
  "baas_price": 206900,
  "buyout_price": 276900,
  "price_diff": 70000,
  "monthly_rent": 599,
  "total_cost_36m": {"baas": 0, "buyout": 0},
  "total_cost_60m": {"baas": 0, "buyout": 0}
}
```

### 4. 优惠信息 `GET /discounts`

**参数**：`model`、`option_count`

**返回**：
```json
{
  "discounts": [
    {"name": "选装阶梯优惠", "description": "选2个减1.6万，选3个减2.3万", "conditions": "option_count >= 2"},
    {"name": "放弃官方金融", "description": "减5000现金", "amount": 5000}
  ]
}
```

### 5. 金融方案 `GET /finance`

**参数**：`model`、`price`、`down_payment_ratio`

**返回**：
```json
{
  "plans": [
    {"name": "7年超低息", "term": 84, "rate": 0, "min_down_payment": 0.2},
    {"name": "5年三免", "term": 60, "free_months": 36, "min_down_payment": 0.2},
    {"name": "浦发银行", "term": 24, "early_settle_after": 24, "min_down_payment": 0.2},
    {"name": "农业银行", "term": 36, "rate": 0.04, "early_settle_after": 36, "min_down_payment": 0.2}
  ],
  "monthly_payment": {"plan_name": "...", "amount": 0, "total_interest": 0, "total_payment": 0}
}
```

### 6. 置换补贴 `GET /subsidies`

**参数**：`subsidy_type`、`car_price`、`city`

**返回**：
```json
{
  "subsidies": [
    {"type": "scrap", "name": "国家报废更新", "rate": 0.12, "max": 20000},
    {"type": "trade_in", "name": "国家置换更新", "rate": 0.08, "max": 15000},
    {"type": "local", "name": "福建地方补贴", "min_price": 200000, "amount": 15000}
  ]
}
```

### 7. 杂费查询 `GET /fees`

**参数**：`car_price`、`model`、`fee_type`（purchase_tax/insurance/registration）

**返回**：
```json
{
  "purchase_tax": 0,
  "insurance": 7500,
  "registration": 230
}
```

### 8. 选装配置 `GET /options`

**参数**：`model`、`option_type`（exterior/interior/package）

**返回**：
```json
{
  "model": "L60",
  "exterior_colors": [
    {"name": "晨曦绿", "price": 0},
    {"name": "云白", "price": 0}
  ],
  "interior_colors": [
    {"name": "雪鸮白", "price": 0},
    {"name": "琥珀橙", "price": 1500}
  ],
  "packages": [
    {"name": "NOMI", "price": 4900},
    {"name": "舒享套装", "price": 3500}
  ]
}
```

### 9. 试驾预约 `POST /test-drive`

**参数**：`name`、`phone`、`model`、`city`

**返回**：`{"status": "success", "message": "已预约，顾问将尽快联系您"}`

### 10. 最新动态 `GET /news`

**返回**：
```json
{
  "news": [
    {"title": "...", "date": "2026-01-15", "type": "milestone"},
    {"title": "换电站突破XXXX座", "date": "2026-01-10", "type": "milestone"}
  ]
}
```

### 11. 换电站查询 `GET /swap-stations`

**参数**：`city`（必填）、`user_lat`、`user_lng`

**返回**：
```json
{
  "city": "福州",
  "total_stations": 28,
  "nearest": {
    "name": "XX换电站",
    "address": "XX区XX路XX号",
    "distance_km": 3.2,
    "supports_onvo": true
  },
  "stations": [...]
}
```

### 12. 换电视频 `GET /swap-video`

**返回**：
```json
{
  "description": "换电流程简述...",
  "links": [
    {"name": "乐道加电地图", "url": "https://www.onvo.cn/map"},
    {"name": "换电演示", "url": "..."}
  ]
}
```

### 13. 换电优势 `GET /swap-advantage`

**返回**：
```json
{
  "advantages": [
    {"title": "补能效率接近加油", "description": "..."},
    {"title": "电池焦虑转嫁给第三方", "description": "..."}
  ],
  "comparison_table": {...}
}
```

### 14. BaaS 经济账 `GET /baas-calc`

**参数**：`model`

**返回**：
```json
{
  "baas_price": 206900,
  "buyout_price": 276900,
  "price_diff": 70000,
  "investment_return": {"rate": 0.035, "monthly_return": 204},
  "total_cost_36m": {"baas": 0, "buyout": 0},
  "total_cost_60m": {"baas": 0, "buyout": 0},
  "recommendations": {...}
}
```

### 15. 报价单留资收集 `POST /quote/lead`

**说明**：用户要求做报价时，不自动生成报价单，而是记录客户信息供销售顾问跟进。

**参数**：`name`、`phone`、`model`（可选）、`budget`（可选）、`notes`（可选）

**返回**：
```json
{"status": "success", "message": "已记录客户信息，顾问将尽快联系您"}
```

### 16. 联系方式 `GET /contact`

**返回**：
```json
{
  "name": "销售顾问姓名",
  "phone": "138-XXXX-XXXX",
  "wecom_qr_code": "/static/images/wecom_qr.png",
  "wecom_url": "https://work.weixin.qq.com/xxx"
}
```

## 注意事项

1. 所有金额单位：元（人民币）
2. 百分比用小数表示（如 0.12 = 12%）
3. 首付比例最低 0.2（20%）
4. 数据源：`config/` 目录下的 YAML 文件
5. 爬虫手动触发，不自动运行

## 错误响应格式

所有接口失败时返回：
```json
{
  "error": "错误描述",
  "code": "ERROR_CODE",
  "detail": "详细信息（可选）"
}
```

常见错误码：
| 错误码 | 说明 |
|--------|------|
| `INVALID_PARAM` | 参数错误 |
| `MODEL_NOT_FOUND` | 车型不存在 |
| `CITY_NOT_SUPPORTED` | 城市不支持 |
| `DATA_UNAVAILABLE` | 数据暂时不可用 |
