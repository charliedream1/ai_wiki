# 翠花 Skill — 4S店销冠汽车销售顾问

基于 186 通真实销售电话录音蒸馏而成的 AI 销售顾问 Skill，适配 Claude Code。

## 她是谁

翠花是一名 4S 店（领克/比亚迪）的销冠级汽车销售顾问，擅长：

- 首次邀约到店
- 老客户跟进邀约
- 客户异议处理
- 逼单成交
- 交付提车全流程

## 数据来源

| 场景 | 电话数量 | 分析文件 |
|------|---------|---------|
| 首次邀约到店 | 125 通 | `_summary_first_invite.md` |
| 老客户跟进邀约 | 53 通 | `_summary_followup.md` |
| 交付提车 | 8 通 | `_summary_delivery.md` |
| 个案分析 | 180+ 通 | `call_XXXX_analysis.md` |

## 安装

```bash
# 全局安装（所有项目可用）
git clone https://github.com/arould001/cui-hua-skill ~/.claude/skills/colleague-cui-hua
```

## 使用

安装后在 Claude Code 中直接使用：

```bash
/cui-hua          # 完整版（销售能力 + 人物性格）
/cui-hua-work     # 仅销售能力
/cui-hua-persona  # 仅人物性格
```

## Skill 结构

```
colleague-cui-hua/
├── SKILL.md      # 入口文件（Claude Code 识别）
├── work.md       # 销售方法论：3大场景SOP、10大异议策略、10大心理杠杆、8类客户画像
├── persona.md    # 人物性格：5层人格结构、表达风格、决策模式、话术示例
└── meta.json     # 元数据
```

## 核心能力

### 销售方法论（work.md）
- **3 大场景 SOP**：首次邀约、老客户跟进、交付提车
- **10 大客户异议应对**：价格、距离、时间、征信、竞品等
- **10 大心理杠杆**：稀缺紧迫感、距离重构、真诚信任、利他框架等
- **8 类客户画像**：价格敏感型、时间紧张型、征信顾虑型、家庭决策型等

### 人物性格（persona.md）
- **Layer 0**：真诚到极致、替客户省钱、不编答案、不重复话术
- **Layer 1**：4S 店销冠，湖南方言亲和力
- **Layer 2**：口语化表达、短句节奏、真人感话术
- **Layer 3**：客户信任 > 短期成交，解决障碍 > 推销话术
- **Layer 4**：把客户当朋友，用温情和幽默化解拒绝
- **Layer 5**：不报虚假低价、不隐瞒费用、不贬低竞品

## License

MIT
